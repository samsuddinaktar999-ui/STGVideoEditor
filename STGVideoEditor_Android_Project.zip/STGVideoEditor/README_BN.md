# STG Video Editor (Android MVP)

এটি CapCut-এর নিজস্ব কোড বা সম্পূর্ণ সমমানের অ্যাপ নয়—এটি একটি স্বাধীন Android ভিডিও এডিটরের শুরু করার মতো MVP।

## এই সংস্করণে
- Android-এর file picker থেকে ভিডিও বাছাই
- ভিডিও preview ও playback controls
- শুরু/শেষের সময় দিয়ে trim
- Media3 Transformer দিয়ে MP4 export
- কোনো Premium লাইসেন্স বাইপাস নেই

## Build করার জন্য
1. Android Studio ইনস্টল করুন (কম্পিউটার লাগবে)।
2. ZIP extract করে `STGVideoEditor` ফোল্ডার Android Studio-তে Open করুন।
3. Gradle sync শেষ হতে দিন।
4. Android SDK 35 ও JDK 17 সেট আছে নিশ্চিত করুন।
5. ফোন USB debugging দিয়ে যুক্ত করে Run চাপুন, অথবা Build > Build APK(s) নির্বাচন করুন।

## আউটপুট কোথায়?
অ্যাপ export করা ভিডিও রাখে app-specific Movies ফোল্ডারে:
`Android/data/com.stg.videoeditor/files/Movies/`

## পরের উন্নয়নের ধাপ
- Multi-clip timeline এবং clip reorder
- Audio/music track ও volume control
- Text/title overlays
- Crop, aspect ratio ও transitions
- Export resolution/bitrate নির্বাচন
- Progress UI, cancellation এবং Android MediaStore-এ export

## গুরুত্বপূর্ণ
এটি starter project; সব ফোন ও সব codec-এ export আচরণ এক হবে এমন নিশ্চয়তা নেই। বাস্তব ব্যবহারের আগে বিভিন্ন ভিডিও, orientation, codec ও Android সংস্করণে পরীক্ষা করুন।
