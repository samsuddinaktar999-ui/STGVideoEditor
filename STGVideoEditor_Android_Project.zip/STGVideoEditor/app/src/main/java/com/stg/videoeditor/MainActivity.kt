package com.stg.videoeditor

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@UnstableApi
class MainActivity : AppCompatActivity() {
    private var selectedVideo: Uri? = null
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var startSeconds: EditText
    private lateinit var endSeconds: EditText
    private lateinit var pickButton: Button
    private lateinit var exportButton: Button
    private var transformer: Transformer? = null

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedVideo = uri
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            preview(uri)
            status.text = "ভিডিও নির্বাচিত হয়েছে। Trim-এর সময় সেকেন্ডে দিন।"
            exportButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20)
            setBackgroundColor(0xFF111118.toInt())
        }

        val title = TextView(this).apply {
            text = "STG VIDEO EDITOR"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 12, 0, 4)
        }
        val subtitle = TextView(this).apply {
            text = "Trim • Preview • Export MP4"
            textSize = 14f
            setTextColor(0xFFBDB9D3.toInt())
        }

        playerView = PlayerView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 220
            ).apply { topMargin = 16; bottomMargin = 14 }
            useController = true
        }

        pickButton = Button(this).apply {
            text = "ভিডিও বেছে নাও"
            setOnClickListener { videoPicker.launch(arrayOf("video/*")) }
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startSeconds = EditText(this).apply {
            hint = "শুরু (সেকেন্ড)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFBDB9D3.toInt())
            setSingleLine(true)
        }
        endSeconds = EditText(this).apply {
            hint = "শেষ (সেকেন্ড)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFBDB9D3.toInt())
            setSingleLine(true)
        }
        timeRow.addView(startSeconds, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        timeRow.addView(endSeconds, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        exportButton = Button(this).apply {
            text = "Trim করে MP4 Export"
            isEnabled = false
            setOnClickListener { exportTrimmedVideo() }
        }

        status = TextView(this).apply {
            text = "শুরু করতে একটি ভিডিও বেছে নাও।"
            textSize = 14f
            setTextColor(0xFF00D7B0.toInt())
            setPadding(0, 12, 0, 0)
        }

        page.addView(title)
        page.addView(subtitle)
        page.addView(playerView)
        page.addView(pickButton)
        page.addView(timeRow)
        page.addView(exportButton)
        page.addView(status)
        setContentView(page)
    }

    private fun preview(uri: Uri) {
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = false
        }
    }

    private fun exportTrimmedVideo() {
        val uri = selectedVideo ?: return
        val startMs = (startSeconds.text.toString().toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0).times(1000).toLong()
        val endMs = (endSeconds.text.toString().toDoubleOrNull() ?: 0.0).times(1000).toLong()

        if (endMs <= 0 || endMs <= startMs) {
            status.text = "শেষের সময় অবশ্যই শুরুর সময়ের চেয়ে বেশি দিতে হবে।"
            return
        }

        val outDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        if (!outDir.exists()) outDir.mkdirs()
        val output = File(outDir, "STG_EDIT_${System.currentTimeMillis()}.mp4")

        val clippedItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()

        val edited = EditedMediaItem.Builder(clippedItem).build()
        exportButton.isEnabled = false
        pickButton.isEnabled = false
        status.text = "Export চলছে… অ্যাপ খোলা রাখো।"

        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        status.text = "Export সম্পন্ন!\nফাইল: ${output.absolutePath}"
                        Toast.makeText(this@MainActivity, "ভিডিও Export হয়েছে", Toast.LENGTH_LONG).show()
                        exportButton.isEnabled = true
                        pickButton.isEnabled = true
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    runOnUiThread {
                        status.text = "Export ব্যর্থ: ${exportException.message ?: "অজানা সমস্যা"}"
                        exportButton.isEnabled = true
                        pickButton.isEnabled = true
                    }
                }
            })
            .build()

        try {
            transformer?.start(edited, output.absolutePath)
        } catch (e: Exception) {
            status.text = "Export শুরু করা যায়নি: ${e.message}"
            exportButton.isEnabled = true
            pickButton.isEnabled = true
        }
    }

    override fun onDestroy() {
        transformer?.cancel()
        player?.release()
        player = null
        super.onDestroy()
    }
}
